<?php
header('Content-Type: application/json; charset=utf-8');

/* =========================================================
   EDIT THIS LINE — where RSVP responses should be emailed.
   Most reliable: a mailbox on your own hosting domain,
   e.g. rsvp@your-site.ru  (set it up in your host panel).
   ========================================================= */
$to = 'sseraya135@gmail.com';

$subject = 'New Wedding RSVP — Aleksandra & Even';

/* Honeypot: silently accept bots, don't email */
if (!empty($_POST['botcheck'])) { echo json_encode(['success' => true]); exit; }

$skip  = ['access_key', 'botcheck', 'subject'];
$lines = [];
foreach ($_POST as $k => $v) {
    if (in_array($k, $skip, true)) continue;
    $v = trim(is_array($v) ? implode(', ', $v) : $v);
    if ($v === '') continue;
    $lines[] = $k . ': ' . $v;
}
$body = implode("\n", $lines);
if ($body === '') { echo json_encode(['success' => false]); exit; }

$host = preg_replace('/[^a-z0-9.\-]/i', '', ($_SERVER['HTTP_HOST'] ?? 'wedding'));
$headers  = 'From: Wedding RSVP <noreply@' . $host . ">\r\n";
$headers .= "Content-Type: text/plain; charset=utf-8\r\n";

$encodedSubject = '=?UTF-8?B?' . base64_encode($subject) . '?=';
$ok = @mail($to, $encodedSubject, $body, $headers);

echo json_encode(['success' => (bool) $ok]);
